<?php
session_start();
    require_once("vendor/autoload.php");

   
?>
<html>
    <?php 
    if(isset($_GET["page"])){
        require_once(pages[isset($_GET["page"])?$_GET["page"]:"all"]);
    }else{ ?>
    <form action="index.php" method="get" >
    <input id="all" type="radio" name="page" value="all"> <label for="all">Get groupof glasses</label>
    <input id="det" type="radio" name="page" value="det"> <label for="det">Get glass by id</label>
    <input type="submit" value="submit">
    </form>
        <?php }?>
</html>