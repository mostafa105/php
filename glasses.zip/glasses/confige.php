<?php 
    const __HOST__ = "localhost";
    const __USER__ =" root";
    const __PASS__ = "";
    const __DB__   = "northwind";
    const __RECORDES_PER_PAGES__ = 5;
    const pages =array ("all"=>"pages/all.php","det"=>"pages/details.php");

?>