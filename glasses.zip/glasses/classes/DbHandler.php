<?php
interface DbHandler {
    public function connect();
    public function get_data($fields = array(),$start);
    public function disconnect();   
    public function get_record_by_id($id);
    
    
}