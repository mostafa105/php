<?php 
 $_SESSION["start"]=0;
    class db implements DbHandler {
       
        private $link;
        private $table ;
        private $sql_query=' select * from ';

        function __construct($TABLE){
            $this->table = $TABLE;
        }

        public function connect(){
            
            $this->link = mysqli_connect(__HOST__ , __USER__ ,__PASS__ ,__DB__);
        }

        public function get_data($fields = array(), $start){
            $que = $this->sql_query . $this->table . ' limit '. __RECORDES_PER_PAGES__ .','.$start;
            $res = mysqli_query($this->link,$que);
            while($record =   mysqli_fetch_assoc($res) ){
                array_push($fields,$record); 
                
            }
            return $fields ; 
        }

        public function disconnect(){
           $this->link->close() ;
        }  

        public function get_record_by_id($id){
            $que =$this->sql_query . $this->table ." where id =" . $id ;
            try{
                $res = mysqli_query($this->link,$que);
                return mysqli_fetch_assoc($res);
            }catch(EXCEPTION $ex){
                // echo $ex;
            };

        }


    }
?>