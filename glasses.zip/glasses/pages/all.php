<?php 
    // $_GET["limit"]
    $_SESSION["start"]=isset($_GET["limit"])?$_GET["start"]:0 ;
     $records= array();
     $db = new db("items");
     $db->connect();
     $records = $db->get_data($records,$_SESSION["start"]);
?>

<html>       
    <body>
        <table style="text-align: center; width:100%;   ">
            <thead>
                <td style="border:1px solid yellow">code</td>
                <td style="border:1px solid yellow">name</td>
                <td style="border:1px solid yellow">price</td>
                <td style="border:1px solid yellow">image</td>
            </thead>
            <?php foreach($records as $recorde){?>
            <tr>
                <?php $tz =explode(".",$recorde["Photo"]); ?>
                <td style="border:1px solid yellow"><?php echo $recorde["PRODUCT_code"]; ?></td>
                <td style="border:1px solid yellow"><?php echo $recorde["product_name"];?></td>
                <td style="border:1px solid yellow"><?php echo $recorde["list_price"];?></td>
                <td style="width:100px;border:1px solid yellow"><a href="http://localhost/glasses/index.php?id=<?php echo $recorde["id"]?>&page=det"><img src="images/<?php echo $tz[0];?>tz.png" alt=""></a></td> 
            </tr>
            <?php }?>
        </table>
               <from method="get" action="index.php"></form>
        
    </body>
</html>