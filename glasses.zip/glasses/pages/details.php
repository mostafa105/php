<?php 
    $db = new db("items");
    $db->connect();
    if(isset($_GET["id"])){
        $rec= $db->get_record_by_id($_GET["id"]); 
        if(!isset($rec["Photo"])){
            $rec["product_name"]="not found" ; $rec["Photo"]="not found";
        }
    }else{
        $_GET["id"] = "17" ;
        $rec= $db->get_record_by_id($_GET["id"]); 
    }
        $db->disconnect();
    ?>
    
    <html>
        <body style = "margin:0px;">
        <h1 style="background-color:yellow ; text-align: center;padding:5px ;margin:0px ;"><?php echo  $rec["product_name"];?></h1>
        <div style ="text-align: center;">
            <img src="images/<?php echo $rec["Photo"];?>" alt=""  >
        </div>
        <form style=" text-align: center;padding:5px ;margin:15px ;"method="get">
            <label for="id"> Get glass by id: - </label>
            <input type="text" name="id" placeholder="enter id">
            <input type="text" name="page" placeholder="enter id" style ="display:none" value="det">
            <input type="submit" value="get"> <a href="http://localhost/glasses/index.php?page=all">Get groupof glasses</a>
        </from>
        <form style=" text-align: center;padding:5px ;margin:15px ;"method="get">

        <form>
        </body>

    </html>
